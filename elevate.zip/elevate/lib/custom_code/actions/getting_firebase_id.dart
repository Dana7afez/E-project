// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<List<String>?> gettingFirebaseId() async {
  // Add your function code here!

  final prefs = await SharedPreferences.getInstance();
  FirebaseMessaging messaging = FirebaseMessaging.instance;

  // Request notification permission
  await messaging.requestPermission();

  // Attempt to get the device token
  String? token = await messaging.getToken();
  if (token == null) {
    print('Failed to retrieve FCM Token');
    return []; // Return an empty list if token retrieval fails
  }

  // Filter users based on isOrg==false
  // Assuming users are stored in a Firestore collection called 'users'
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('users')
      .where('isOrg', isEqualTo: false)
      .get();

  List<String> fcmTokens = [];

  // Collect FCM tokens for users who are not organizations
  for (var doc in querySnapshot.docs) {
    var data = doc.data() as Map<String, dynamic>?; // Safely cast to Map
    if (data != null && data.containsKey('fcmToken')) {
      fcmTokens.add(data['fcmToken'] as String);
    }
  }

  // Optionally add the retrieved token to the list of tokens
  fcmTokens.add(token);

  return fcmTokens; // Return the list of FCM tokens
}
