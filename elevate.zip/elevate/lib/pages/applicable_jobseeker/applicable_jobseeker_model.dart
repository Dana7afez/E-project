import '/flutter_flow/flutter_flow_util.dart';
import 'applicable_jobseeker_widget.dart' show ApplicableJobseekerWidget;
import 'package:flutter/material.dart';

class ApplicableJobseekerModel
    extends FlutterFlowModel<ApplicableJobseekerWidget> {
  ///  Local state fields for this page.

  String jobseekerID = 'jobseekerID';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
