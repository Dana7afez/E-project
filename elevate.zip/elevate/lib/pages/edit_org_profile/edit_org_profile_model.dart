import '/flutter_flow/flutter_flow_util.dart';
import 'edit_org_profile_widget.dart' show EditOrgProfileWidget;
import 'package:flutter/material.dart';

class EditOrgProfileModel extends FlutterFlowModel<EditOrgProfileWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for OrganaizationName widget.
  FocusNode? organaizationNameFocusNode;
  TextEditingController? organaizationNameTextController;
  String? Function(BuildContext, String?)?
      organaizationNameTextControllerValidator;
  String? _organaizationNameTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Required Field!!';
    }

    return null;
  }

  // State field(s) for OrgEmail widget.
  FocusNode? orgEmailFocusNode;
  TextEditingController? orgEmailTextController;
  String? Function(BuildContext, String?)? orgEmailTextControllerValidator;
  String? _orgEmailTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Required Field!!';
    }

    return null;
  }

  // State field(s) for OrgPhoneNumber widget.
  FocusNode? orgPhoneNumberFocusNode;
  TextEditingController? orgPhoneNumberTextController;
  String? Function(BuildContext, String?)?
      orgPhoneNumberTextControllerValidator;
  String? _orgPhoneNumberTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Required Field!!';
    }

    return null;
  }

  @override
  void initState(BuildContext context) {
    organaizationNameTextControllerValidator =
        _organaizationNameTextControllerValidator;
    orgEmailTextControllerValidator = _orgEmailTextControllerValidator;
    orgPhoneNumberTextControllerValidator =
        _orgPhoneNumberTextControllerValidator;
  }

  @override
  void dispose() {
    organaizationNameFocusNode?.dispose();
    organaizationNameTextController?.dispose();

    orgEmailFocusNode?.dispose();
    orgEmailTextController?.dispose();

    orgPhoneNumberFocusNode?.dispose();
    orgPhoneNumberTextController?.dispose();
  }
}
