import '/flutter_flow/flutter_flow_util.dart';
import 'main_quiz_page_copy2_widget.dart' show MainQuizPageCopy2Widget;
import 'package:flutter/material.dart';

class MainQuizPageCopy2Model extends FlutterFlowModel<MainQuizPageCopy2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
