import '/flutter_flow/flutter_flow_util.dart';
import 'applicable_jobseeker_copy_widget.dart'
    show ApplicableJobseekerCopyWidget;
import 'package:flutter/material.dart';

class ApplicableJobseekerCopyModel
    extends FlutterFlowModel<ApplicableJobseekerCopyWidget> {
  ///  Local state fields for this page.

  String jobseekerID = 'jobseekerID';

  String documentID = 'documentID';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
