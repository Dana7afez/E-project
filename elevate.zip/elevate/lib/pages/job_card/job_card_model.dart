import '/flutter_flow/flutter_flow_util.dart';
import 'job_card_widget.dart' show JobCardWidget;
import 'package:flutter/material.dart';

class JobCardModel extends FlutterFlowModel<JobCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
