import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'empty_quizzes_model.dart';
export 'empty_quizzes_model.dart';

class EmptyQuizzesWidget extends StatefulWidget {
  const EmptyQuizzesWidget({super.key});

  @override
  State<EmptyQuizzesWidget> createState() => _EmptyQuizzesWidgetState();
}

class _EmptyQuizzesWidgetState extends State<EmptyQuizzesWidget> {
  late EmptyQuizzesModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => EmptyQuizzesModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 262.0,
      height: 131.0,
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          Align(
            alignment: const AlignmentDirectional(0.0, 0.0),
            child: Text(
              'No Quizzes Yet',
              style: FlutterFlowTheme.of(context).headlineMedium.override(
                    fontFamily: 'Figtree',
                    letterSpacing: 0.0,
                  ),
            ),
          ),
          Padding(
            padding: const EdgeInsetsDirectional.fromSTEB(0.0, 15.0, 0.0, 0.0),
            child: Icon(
              FFIcons.kimageIndentRight,
              color: FlutterFlowTheme.of(context).primary,
              size: 55.0,
            ),
          ),
        ],
      ),
    );
  }
}
