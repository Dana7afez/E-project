import '/flutter_flow/flutter_flow_util.dart';
import 'empty_quizzes_widget.dart' show EmptyQuizzesWidget;
import 'package:flutter/material.dart';

class EmptyQuizzesModel extends FlutterFlowModel<EmptyQuizzesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
