import '/flutter_flow/flutter_flow_util.dart';
import 'job_menu_options_widget.dart' show JobMenuOptionsWidget;
import 'package:flutter/material.dart';

class JobMenuOptionsModel extends FlutterFlowModel<JobMenuOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
