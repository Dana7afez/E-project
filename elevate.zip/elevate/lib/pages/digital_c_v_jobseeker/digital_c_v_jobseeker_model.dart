import '/flutter_flow/flutter_flow_util.dart';
import 'digital_c_v_jobseeker_widget.dart' show DigitalCVJobseekerWidget;
import 'package:flutter/material.dart';

class DigitalCVJobseekerModel
    extends FlutterFlowModel<DigitalCVJobseekerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
