import '/flutter_flow/flutter_flow_util.dart';
import 'experience_widget.dart' show ExperienceWidget;
import 'package:flutter/material.dart';

class ExperienceModel extends FlutterFlowModel<ExperienceWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for CompanName widget.
  FocusNode? companNameFocusNode;
  TextEditingController? companNameTextController;
  String? Function(BuildContext, String?)? companNameTextControllerValidator;
  // State field(s) for PositionName widget.
  FocusNode? positionNameFocusNode;
  TextEditingController? positionNameTextController;
  String? Function(BuildContext, String?)? positionNameTextControllerValidator;
  // State field(s) for CompanyAddress widget.
  FocusNode? companyAddressFocusNode;
  TextEditingController? companyAddressTextController;
  String? Function(BuildContext, String?)?
      companyAddressTextControllerValidator;
  DateTime? datePicked1;
  DateTime? datePicked2;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    companNameFocusNode?.dispose();
    companNameTextController?.dispose();

    positionNameFocusNode?.dispose();
    positionNameTextController?.dispose();

    companyAddressFocusNode?.dispose();
    companyAddressTextController?.dispose();
  }
}
