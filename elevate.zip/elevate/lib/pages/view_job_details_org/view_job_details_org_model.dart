import '/flutter_flow/flutter_flow_util.dart';
import 'view_job_details_org_widget.dart' show ViewJobDetailsOrgWidget;
import 'package:flutter/material.dart';

class ViewJobDetailsOrgModel extends FlutterFlowModel<ViewJobDetailsOrgWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
