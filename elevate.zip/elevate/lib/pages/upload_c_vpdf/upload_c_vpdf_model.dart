import '/flutter_flow/flutter_flow_util.dart';
import 'upload_c_vpdf_widget.dart' show UploadCVpdfWidget;
import 'package:flutter/material.dart';

class UploadCVpdfModel extends FlutterFlowModel<UploadCVpdfWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
