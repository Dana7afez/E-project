import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'jobeeker_view_job_details_widget.dart'
    show JobeekerViewJobDetailsWidget;
import 'package:flutter/material.dart';

class JobeekerViewJobDetailsModel
    extends FlutterFlowModel<JobeekerViewJobDetailsWidget> {
  ///  Local state fields for this page.

  String? selectedSkill;

  String jobTitle = 'jobTitle';

  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (GetFirstQuestion)] action in Button widget.
  ApiCallResponse? getFirstQuestion;
  // Stores action output result for [Backend Call - API (GetSecondQuestion)] action in Button widget.
  ApiCallResponse? getSecondQuestion;
  // Stores action output result for [Backend Call - API (GetThirdQuestion)] action in Button widget.
  ApiCallResponse? getThirdQuestion;
  // Stores action output result for [Backend Call - API (GetFourthQuestion)] action in Button widget.
  ApiCallResponse? getFourthQuestion;
  // Stores action output result for [Backend Call - API (GetFifthQuestion)] action in Button widget.
  ApiCallResponse? getFifthQuestion;
  // Stores action output result for [Backend Call - API (GetSixthQuestion)] action in Button widget.
  ApiCallResponse? getSixthQuestion;
  // Stores action output result for [Backend Call - API (GetSeventhQuestion)] action in Button widget.
  ApiCallResponse? getSeventhQuestion;
  // Stores action output result for [Backend Call - API (GetEighthQuestion)] action in Button widget.
  ApiCallResponse? getEighthQuestion;
  // Stores action output result for [Backend Call - API (GetNinthQuestion )] action in Button widget.
  ApiCallResponse? getNinthQuestion;
  // Stores action output result for [Backend Call - API (GetTenthQuestion )] action in Button widget.
  ApiCallResponse? getTenthQuestion;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
