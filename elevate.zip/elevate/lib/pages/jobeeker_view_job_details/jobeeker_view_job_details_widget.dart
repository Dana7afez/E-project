import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'jobeeker_view_job_details_model.dart';
export 'jobeeker_view_job_details_model.dart';

class JobeekerViewJobDetailsWidget extends StatefulWidget {
  const JobeekerViewJobDetailsWidget({
    super.key,
    required this.selectedJobTitle,
  });

  final String? selectedJobTitle;

  @override
  State<JobeekerViewJobDetailsWidget> createState() =>
      _JobeekerViewJobDetailsWidgetState();
}

class _JobeekerViewJobDetailsWidgetState
    extends State<JobeekerViewJobDetailsWidget> {
  late JobeekerViewJobDetailsModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => JobeekerViewJobDetailsModel());

    // On page load action.
    SchedulerBinding.instance.addPostFrameCallback((_) async {
      _model.jobTitle = widget.selectedJobTitle!;
      safeSetState(() {});
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
        body: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: 200.0,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: Image.asset(
                      'assets/images/WEBSITE_HEADER_1920_1080_ADOBESTOCK_257756024.png',
                    ).image,
                  ),
                  gradient: const LinearGradient(
                    colors: [Color(0xFF6970D5), Color(0xFF4B39EF)],
                    stops: [0.0, 1.0],
                    begin: AlignmentDirectional(0.0, -1.0),
                    end: AlignmentDirectional(0, 1.0),
                  ),
                ),
                child: Padding(
                  padding:
                      const EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 24.0, 0.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          FlutterFlowIconButton(
                            borderColor: Colors.transparent,
                            borderRadius: 20.0,
                            buttonSize: 40.0,
                            fillColor: const Color(0x33FFFFFF),
                            icon: const Icon(
                              Icons.arrow_back,
                              color: Colors.white,
                              size: 24.0,
                            ),
                            onPressed: () async {
                              context.safePop();
                            },
                          ),
                        ],
                      ),
                      Align(
                        alignment: const AlignmentDirectional(0.0, 0.0),
                        child: Padding(
                          padding: const EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 10.0),
                          child: Material(
                            color: Colors.transparent,
                            elevation: 4.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(50.0),
                            ),
                            child: Container(
                              width: 100.0,
                              height: 100.0,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(50.0),
                              ),
                              child: Align(
                                alignment: const AlignmentDirectional(0.0, 0.0),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(50.0),
                                  child: Image.asset(
                                    'assets/images/3688609.png',
                                    width: 100.0,
                                    height: 100.0,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                decoration: BoxDecoration(
                  color: FlutterFlowTheme.of(context).secondaryBackground,
                  borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(0.0),
                    bottomRight: Radius.circular(0.0),
                    topLeft: Radius.circular(32.0),
                    topRight: Radius.circular(32.0),
                  ),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.fromSTEB(
                          24.0, 24.0, 24.0, 24.0),
                      child: StreamBuilder<List<JobCollectionRecord>>(
                        stream: queryJobCollectionRecord(
                          queryBuilder: (jobCollectionRecord) =>
                              jobCollectionRecord.where(
                            'JobTitle',
                            isEqualTo: _model.jobTitle,
                          ),
                          singleRecord: true,
                        ),
                        builder: (context, snapshot) {
                          // Customize what your widget looks like when it's loading.
                          if (!snapshot.hasData) {
                            return Center(
                              child: SizedBox(
                                width: 50.0,
                                height: 50.0,
                                child: SpinKitThreeBounce(
                                  color: FlutterFlowTheme.of(context).primary,
                                  size: 50.0,
                                ),
                              ),
                            );
                          }
                          List<JobCollectionRecord>
                              columnJobCollectionRecordList = snapshot.data!;
                          // Return an empty Container when the item does not exist.
                          if (snapshot.data!.isEmpty) {
                            return Container();
                          }
                          final columnJobCollectionRecord =
                              columnJobCollectionRecordList.isNotEmpty
                                  ? columnJobCollectionRecordList.first
                                  : null;

                          return Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    valueOrDefault<String>(
                                      columnJobCollectionRecord?.jobTitle,
                                      'JobTitle',
                                    ),
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.of(context)
                                        .headlineMedium
                                        .override(
                                          fontFamily: 'Figtree',
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                  ),
                                  Text(
                                    valueOrDefault<String>(
                                      columnJobCollectionRecord?.catagory,
                                      'Catagory',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .titleMedium
                                        .override(
                                          fontFamily: 'Plus Jakarta Sans',
                                          color: FlutterFlowTheme.of(context)
                                              .primary,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(
                                        Icons.location_on,
                                        color: FlutterFlowTheme.of(context)
                                            .secondaryText,
                                        size: 20.0,
                                      ),
                                      Padding(
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 20.0, 0.0),
                                        child: Text(
                                          valueOrDefault<String>(
                                            columnJobCollectionRecord?.location,
                                            'location ',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryText,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                      Icon(
                                        Icons.attach_money,
                                        color: FlutterFlowTheme.of(context)
                                            .primaryText,
                                        size: 24.0,
                                      ),
                                      Align(
                                        alignment:
                                            const AlignmentDirectional(0.0, 0.0),
                                        child: Text(
                                          valueOrDefault<String>(
                                            columnJobCollectionRecord?.salary,
                                            'l',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ].divide(const SizedBox(width: 8.0)),
                                  ),
                                ].divide(const SizedBox(height: 8.0)),
                              ),
                              SizedBox(
                                height: 40.0,
                                child: ListView(
                                  padding: EdgeInsets.zero,
                                  primary: false,
                                  shrinkWrap: true,
                                  scrollDirection: Axis.horizontal,
                                  children: [
                                    Container(
                                      height: 48.0,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE0E3E7),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      alignment: const AlignmentDirectional(0.0, 0.0),
                                      child: Padding(
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            8.0, 0.0, 8.0, 0.0),
                                        child: Text(
                                          valueOrDefault<String>(
                                            columnJobCollectionRecord?.jobType2,
                                            'a',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE0E3E7),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            8.0, 10.0, 8.0, 0.0),
                                        child: Text(
                                          valueOrDefault<String>(
                                            columnJobCollectionRecord?.jobType1,
                                            'a',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFE0E3E7),
                                        borderRadius:
                                            BorderRadius.circular(20.0),
                                      ),
                                      child: Padding(
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            8.0, 10.0, 8.0, 0.0),
                                        child: Text(
                                          'Expert years: ${columnJobCollectionRecord?.expyears}',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primaryText,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ].divide(const SizedBox(width: 8.0)),
                                ),
                              ),
                              SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisSize: MainAxisSize.max,
                                      children: [
                                        Text(
                                          '• REQUIRED SKILLS:',
                                          style: FlutterFlowTheme.of(context)
                                              .bodySmall
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .secondaryText,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.w600,
                                              ),
                                        ),
                                      ],
                                    ),
                                    Align(
                                      alignment:
                                          const AlignmentDirectional(-1.0, 0.0),
                                      child: Padding(
                                        padding: const EdgeInsetsDirectional.fromSTEB(
                                            0.0, 0.0, 30.0, 0.0),
                                        child: Text(
                                          '  Hint: Click the button below to take a quiz on the required job skill.',
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Plus Jakarta Sans',
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                letterSpacing: 0.0,
                                              ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 40.0,
                                      child: Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Container(
                                            width: 200.0,
                                            height: 121.0,
                                            decoration: BoxDecoration(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .secondaryBackground,
                                            ),
                                            child: Align(
                                              alignment: const AlignmentDirectional(
                                                  -1.0, -1.0),
                                              child: Stack(
                                                children: [
                                                  SingleChildScrollView(
                                                    scrollDirection:
                                                        Axis.horizontal,
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      children: [
                                                        Padding(
                                                          padding:
                                                              const EdgeInsetsDirectional
                                                                  .fromSTEB(
                                                                      0.0,
                                                                      10.0,
                                                                      0.0,
                                                                      0.0),
                                                          child: Text(
                                                            valueOrDefault<
                                                                String>(
                                                              columnJobCollectionRecord
                                                                  ?.jobSkill,
                                                              'JobSkill',
                                                            ),
                                                            style: FlutterFlowTheme
                                                                    .of(context)
                                                                .bodyMedium
                                                                .override(
                                                                  fontFamily:
                                                                      'Plus Jakarta Sans',
                                                                  letterSpacing:
                                                                      0.0,
                                                                ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ].divide(const SizedBox(height: 12.0)),
                                ),
                              ),
                              Align(
                                alignment: const AlignmentDirectional(-1.85, 3.32),
                                child: Padding(
                                  padding: const EdgeInsetsDirectional.fromSTEB(
                                      80.0, 0.0, 0.0, 0.0),
                                  child: FFButtonWidget(
                                    onPressed: () async {
                                      _model.getFirstQuestion =
                                          await GetFirstQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getSecondQuestion =
                                          await GetSecondQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getThirdQuestion =
                                          await GetThirdQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getFourthQuestion =
                                          await GetFourthQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getFifthQuestion =
                                          await GetFifthQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getSixthQuestion =
                                          await GetSixthQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getSeventhQuestion =
                                          await GetSeventhQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getEighthQuestion =
                                          await GetEighthQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getNinthQuestion =
                                          await GetNinthQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      _model.getTenthQuestion =
                                          await GetTenthQuestionCall.call(
                                        skill:
                                            columnJobCollectionRecord?.jobSkill,
                                      );

                                      context.pushNamed(
                                        'AIQuiz',
                                        queryParameters: {
                                          'skill': serializeParam(
                                            columnJobCollectionRecord?.jobSkill,
                                            ParamType.String,
                                          ),
                                          'question1': serializeParam(
                                            getJsonField(
                                              (_model.getFirstQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'quesetion2': serializeParam(
                                            getJsonField(
                                              (_model.getSecondQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question3': serializeParam(
                                            getJsonField(
                                              (_model.getThirdQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question4': serializeParam(
                                            getJsonField(
                                              (_model.getFourthQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question5': serializeParam(
                                            getJsonField(
                                              (_model.getFifthQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question6': serializeParam(
                                            getJsonField(
                                              (_model.getSixthQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question7': serializeParam(
                                            getJsonField(
                                              (_model.getSeventhQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question8': serializeParam(
                                            getJsonField(
                                              (_model.getEighthQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question9': serializeParam(
                                            getJsonField(
                                              (_model.getNinthQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                          'question10': serializeParam(
                                            getJsonField(
                                              (_model.getTenthQuestion
                                                      ?.jsonBody ??
                                                  ''),
                                              r'''$.choices[:].message.content''',
                                            ).toString(),
                                            ParamType.String,
                                          ),
                                        }.withoutNulls,
                                      );

                                      safeSetState(() {});
                                    },
                                    text: 'Test yourself!',
                                    options: FFButtonOptions(
                                      width: 120.0,
                                      height: 30.0,
                                      padding: const EdgeInsetsDirectional.fromSTEB(
                                          16.0, 0.0, 16.0, 0.0),
                                      iconPadding:
                                          const EdgeInsetsDirectional.fromSTEB(
                                              0.0, 0.0, 0.0, 0.0),
                                      color:
                                          FlutterFlowTheme.of(context).primary,
                                      textStyle: FlutterFlowTheme.of(context)
                                          .titleSmall
                                          .override(
                                            fontFamily: 'Plus Jakarta Sans',
                                            color: Colors.white,
                                            letterSpacing: 0.0,
                                          ),
                                      elevation: 0.0,
                                      borderRadius: BorderRadius.circular(22.0),
                                    ),
                                  ),
                                ),
                              ),
                              Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '• JOB DESCRIPTION:',
                                    style: FlutterFlowTheme.of(context)
                                        .bodySmall
                                        .override(
                                          fontFamily: 'Plus Jakarta Sans',
                                          color: FlutterFlowTheme.of(context)
                                              .secondaryText,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                  Text(
                                    valueOrDefault<String>(
                                      columnJobCollectionRecord?.description,
                                      'a',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Plus Jakarta Sans',
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                  Text(
                                    '• RESPONSIBILITIES:',
                                    style: FlutterFlowTheme.of(context)
                                        .bodySmall
                                        .override(
                                          fontFamily: 'Plus Jakarta Sans',
                                          color: FlutterFlowTheme.of(context)
                                              .secondaryText,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                        ),
                                  ),
                                  Text(
                                    valueOrDefault<String>(
                                      columnJobCollectionRecord
                                          ?.responsibilities,
                                      'l',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Plus Jakarta Sans',
                                          color: FlutterFlowTheme.of(context)
                                              .primaryText,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ].divide(const SizedBox(height: 12.0)),
                              ),
                            ].divide(const SizedBox(height: 24.0)),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
