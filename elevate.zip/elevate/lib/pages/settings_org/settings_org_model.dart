import '/flutter_flow/flutter_flow_util.dart';
import '/pages/org_nav_bar/org_nav_bar_widget.dart';
import 'settings_org_widget.dart' show SettingsOrgWidget;
import 'package:flutter/material.dart';

class SettingsOrgModel extends FlutterFlowModel<SettingsOrgWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for orgNavBar component.
  late OrgNavBarModel orgNavBarModel;

  @override
  void initState(BuildContext context) {
    orgNavBarModel = createModel(context, () => OrgNavBarModel());
  }

  @override
  void dispose() {
    orgNavBarModel.dispose();
  }
}
