import '/flutter_flow/flutter_flow_util.dart';
import 'org_nav_bar_widget.dart' show OrgNavBarWidget;
import 'package:flutter/material.dart';

class OrgNavBarModel extends FlutterFlowModel<OrgNavBarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
