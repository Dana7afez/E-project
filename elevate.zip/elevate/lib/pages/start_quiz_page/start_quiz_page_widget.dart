import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'start_quiz_page_model.dart';
export 'start_quiz_page_model.dart';

class StartQuizPageWidget extends StatefulWidget {
  const StartQuizPageWidget({super.key});

  @override
  State<StartQuizPageWidget> createState() => _StartQuizPageWidgetState();
}

class _StartQuizPageWidgetState extends State<StartQuizPageWidget> {
  late StartQuizPageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => StartQuizPageModel());

    _model.skillFieldTextController ??=
        TextEditingController(text: _model.skill);
    _model.skillFieldFocusNode ??= FocusNode();

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: SizedBox(
          width: MediaQuery.sizeOf(context).width * 1.0,
          height: MediaQuery.sizeOf(context).height * 1.0,
          child: Stack(
            children: [
              Container(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: MediaQuery.sizeOf(context).height * 1.0,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFFE8EAF6), Color(0x876970D5)],
                    stops: [0.0, 1.0],
                    begin: AlignmentDirectional(0.0, -1.0),
                    end: AlignmentDirectional(0, 1.0),
                  ),
                ),
                child: Align(
                  alignment: const AlignmentDirectional(0.0, 0.0),
                  child: Padding(
                    padding:
                        const EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 24.0, 24.0),
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.lightbulb_outline,
                            color: FlutterFlowTheme.of(context).primary,
                            size: 64.0,
                          ),
                          Text(
                            'Quiz',
                            style: FlutterFlowTheme.of(context)
                                .displayLarge
                                .override(
                                  fontFamily: 'Figtree',
                                  color: FlutterFlowTheme.of(context).primary,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            'Test your skills and knowledge! Let\'s start your personalized quiz.\n\nEnter a Skill that You want to be Quized on',
                            textAlign: TextAlign.center,
                            style: FlutterFlowTheme.of(context)
                                .bodyLarge
                                .override(
                                  fontFamily: 'Plus Jakarta Sans',
                                  color: FlutterFlowTheme.of(context).primary,
                                  letterSpacing: 0.0,
                                ),
                          ),
                          Material(
                            color: Colors.transparent,
                            elevation: 4.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16.0),
                            ),
                            child: Container(
                              width: MediaQuery.sizeOf(context).width * 0.9,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16.0),
                              ),
                              child: Padding(
                                padding: const EdgeInsetsDirectional.fromSTEB(
                                    24.0, 24.0, 24.0, 24.0),
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Align(
                                      alignment: const AlignmentDirectional(0.0, 0.0),
                                      child: SizedBox(
                                        width: double.infinity,
                                        child: Form(
                                          key: _model.formKey,
                                          autovalidateMode:
                                              AutovalidateMode.always,
                                          child: Column(
                                            mainAxisSize: MainAxisSize.max,
                                            children: [
                                              Padding(
                                                padding: const EdgeInsetsDirectional
                                                    .fromSTEB(
                                                        0.0, 0.0, 0.0, 6.0),
                                                child: TextFormField(
                                                  controller: _model
                                                      .skillFieldTextController,
                                                  focusNode: _model
                                                      .skillFieldFocusNode,
                                                  onFieldSubmitted: (_) async {
                                                    safeSetState(() {
                                                      _model.skillFieldTextController
                                                              ?.text =
                                                          _model
                                                              .skillFieldTextController
                                                              .text;
                                                    });
                                                  },
                                                  autofocus: false,
                                                  obscureText: false,
                                                  decoration: InputDecoration(
                                                    labelText:
                                                        'Enter your skill ',
                                                    labelStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    hintText:
                                                        'eg. Java, Web, ...',
                                                    hintStyle: FlutterFlowTheme
                                                            .of(context)
                                                        .bodyMedium
                                                        .override(
                                                          fontFamily:
                                                              'Plus Jakarta Sans',
                                                          letterSpacing: 0.0,
                                                        ),
                                                    enabledBorder:
                                                        OutlineInputBorder(
                                                      borderSide: const BorderSide(
                                                        color:
                                                            Color(0xFF3F51B5),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                    ),
                                                    focusedBorder:
                                                        OutlineInputBorder(
                                                      borderSide: const BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                    ),
                                                    errorBorder:
                                                        OutlineInputBorder(
                                                      borderSide: const BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                    ),
                                                    focusedErrorBorder:
                                                        OutlineInputBorder(
                                                      borderSide: const BorderSide(
                                                        color:
                                                            Color(0x00000000),
                                                        width: 1.0,
                                                      ),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12.0),
                                                    ),
                                                    filled: true,
                                                    fillColor:
                                                        const Color(0xFFF5F5F5),
                                                  ),
                                                  style: FlutterFlowTheme.of(
                                                          context)
                                                      .bodyLarge
                                                      .override(
                                                        fontFamily:
                                                            'Plus Jakarta Sans',
                                                        letterSpacing: 0.0,
                                                      ),
                                                  minLines: 1,
                                                  maxLength: 25,
                                                  maxLengthEnforcement:
                                                      MaxLengthEnforcement
                                                          .enforced,
                                                  validator: _model
                                                      .skillFieldTextControllerValidator
                                                      .asValidator(context),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ].divide(const SizedBox(height: 10.0)),
                                ),
                              ),
                            ),
                          ),
                          FFButtonWidget(
                            onPressed: (_model.skillFieldTextController.text ==
                                    '')
                                ? null
                                : () async {
                                    if (_model.formKey.currentState != null) {
                                      _model.formKey.currentState!.validate();
                                    }
                                    _model.skill =
                                        _model.skillFieldTextController.text;
                                    safeSetState(() {});
                                    _model.getFirstQuestion =
                                        await GetFirstQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getSecondQuestion =
                                        await GetSecondQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getThirdQuestion =
                                        await GetThirdQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getFourthQuestion =
                                        await GetFourthQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getFifthQuestion =
                                        await GetFifthQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getSixthQuestion =
                                        await GetSixthQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getSeventhQuestion =
                                        await GetSeventhQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getEighthQuestion =
                                        await GetEighthQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getNinthQuestion =
                                        await GetNinthQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    _model.getTenthQuestion =
                                        await GetTenthQuestionCall.call(
                                      skill: _model.skill,
                                    );

                                    context.pushNamed(
                                      'AIQuiz',
                                      queryParameters: {
                                        'skill': serializeParam(
                                          _model.skill,
                                          ParamType.String,
                                        ),
                                        'question1': serializeParam(
                                          getJsonField(
                                            (_model.getFirstQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'quesetion2': serializeParam(
                                          getJsonField(
                                            (_model.getSecondQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question3': serializeParam(
                                          getJsonField(
                                            (_model.getThirdQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question4': serializeParam(
                                          getJsonField(
                                            (_model.getFourthQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question5': serializeParam(
                                          getJsonField(
                                            (_model.getFifthQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question6': serializeParam(
                                          getJsonField(
                                            (_model.getSixthQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question7': serializeParam(
                                          getJsonField(
                                            (_model.getSeventhQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question8': serializeParam(
                                          getJsonField(
                                            (_model.getEighthQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question9': serializeParam(
                                          getJsonField(
                                            (_model.getNinthQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                        'question10': serializeParam(
                                          getJsonField(
                                            (_model.getTenthQuestion
                                                    ?.jsonBody ??
                                                ''),
                                            r'''$.choices[:].message.content''',
                                          ).toString(),
                                          ParamType.String,
                                        ),
                                      }.withoutNulls,
                                    );

                                    safeSetState(() {});
                                  },
                            text: 'Start Quiz',
                            options: FFButtonOptions(
                              width: MediaQuery.sizeOf(context).width * 0.9,
                              height: 60.0,
                              padding: const EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              iconPadding: const EdgeInsetsDirectional.fromSTEB(
                                  0.0, 0.0, 0.0, 0.0),
                              color: FlutterFlowTheme.of(context).primary,
                              textStyle: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Figtree',
                                    color: Colors.white,
                                    letterSpacing: 0.0,
                                  ),
                              elevation: 3.0,
                              borderRadius: BorderRadius.circular(30.0),
                              disabledColor:
                                  FlutterFlowTheme.of(context).secondaryText,
                            ),
                          ),
                        ].divide(const SizedBox(height: 24.0)),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                width: MediaQuery.sizeOf(context).width * 1.0,
                height: MediaQuery.sizeOf(context).height * 1.0,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsetsDirectional.fromSTEB(
                          24.0, 24.0, 24.0, 24.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          FlutterFlowIconButton(
                            borderColor: Colors.transparent,
                            borderRadius: 20.0,
                            buttonSize: 40.0,
                            fillColor: const Color(0x33FFFFFF),
                            icon: const Icon(
                              Icons.arrow_back,
                              color: Color(0xFF6970D5),
                              size: 24.0,
                            ),
                            onPressed: () async {
                              context.pushNamed('MainQuizPage');
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
