import '/flutter_flow/flutter_flow_util.dart';
import 'check_email_widget.dart' show CheckEmailWidget;
import 'package:flutter/material.dart';

class CheckEmailModel extends FlutterFlowModel<CheckEmailWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
