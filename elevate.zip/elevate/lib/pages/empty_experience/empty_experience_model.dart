import '/flutter_flow/flutter_flow_util.dart';
import 'empty_experience_widget.dart' show EmptyExperienceWidget;
import 'package:flutter/material.dart';

class EmptyExperienceModel extends FlutterFlowModel<EmptyExperienceWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
