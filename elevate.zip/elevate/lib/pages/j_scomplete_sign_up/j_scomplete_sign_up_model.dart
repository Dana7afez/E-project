import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/form_field_controller.dart';
import 'j_scomplete_sign_up_widget.dart' show JScompleteSignUpWidget;
import 'package:flutter/material.dart';

class JScompleteSignUpModel extends FlutterFlowModel<JScompleteSignUpWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for FName widget.
  FocusNode? fNameFocusNode;
  TextEditingController? fNameTextController;
  String? Function(BuildContext, String?)? fNameTextControllerValidator;
  String? _fNameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required!';
    }

    if (val.length > 30) {
      return 'This field cannot exceed  30 characters!';
    }
    if (!RegExp('^[A-Za-z]{2,30}\$').hasMatch(val)) {
      return 'Please enter a valid name!';
    }
    return null;
  }

  // State field(s) for LName widget.
  FocusNode? lNameFocusNode;
  TextEditingController? lNameTextController;
  String? Function(BuildContext, String?)? lNameTextControllerValidator;
  String? _lNameTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required!';
    }

    if (val.length > 30) {
      return 'This field cannot exceed  30 characters!';
    }
    if (!RegExp('^[A-Za-z]{2,30}\$').hasMatch(val)) {
      return 'Please enter a valid name!';
    }
    return null;
  }

  // State field(s) for Position widget.
  String? positionValue;
  FormFieldController<String>? positionValueController;
  // State field(s) for City widget.
  String? cityValue;
  FormFieldController<String>? cityValueController;
  // State field(s) for Gender widget.
  FormFieldController<List<String>>? genderValueController;
  String? get genderValue => genderValueController?.value?.firstOrNull;
  set genderValue(String? val) =>
      genderValueController?.value = val != null ? [val] : [];
  DateTime? datePicked;
  // State field(s) for Skills widget.
  FocusNode? skillsFocusNode;
  TextEditingController? skillsTextController;
  String? Function(BuildContext, String?)? skillsTextControllerValidator;

  @override
  void initState(BuildContext context) {
    fNameTextControllerValidator = _fNameTextControllerValidator;
    lNameTextControllerValidator = _lNameTextControllerValidator;
  }

  @override
  void dispose() {
    fNameFocusNode?.dispose();
    fNameTextController?.dispose();

    lNameFocusNode?.dispose();
    lNameTextController?.dispose();

    skillsFocusNode?.dispose();
    skillsTextController?.dispose();
  }
}
