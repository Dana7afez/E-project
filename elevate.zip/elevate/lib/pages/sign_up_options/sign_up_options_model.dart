import '/flutter_flow/flutter_flow_util.dart';
import 'sign_up_options_widget.dart' show SignUpOptionsWidget;
import 'package:flutter/material.dart';

class SignUpOptionsModel extends FlutterFlowModel<SignUpOptionsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
