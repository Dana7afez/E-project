import '/flutter_flow/flutter_flow_util.dart';
import 'quiz_finished_widget.dart' show QuizFinishedWidget;
import 'package:flutter/material.dart';

class QuizFinishedModel extends FlutterFlowModel<QuizFinishedWidget> {
  ///  Local state fields for this component.

  String answers = 'A, B, C, D, A, D, C, C, D, A';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
