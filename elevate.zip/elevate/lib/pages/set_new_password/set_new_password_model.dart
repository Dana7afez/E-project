import '/flutter_flow/flutter_flow_util.dart';
import 'set_new_password_widget.dart' show SetNewPasswordWidget;
import 'package:flutter/material.dart';

class SetNewPasswordModel extends FlutterFlowModel<SetNewPasswordWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for NewPasswordField widget.
  FocusNode? newPasswordFieldFocusNode;
  TextEditingController? newPasswordFieldTextController;
  late bool newPasswordFieldVisibility;
  String? Function(BuildContext, String?)?
      newPasswordFieldTextControllerValidator;
  String? _newPasswordFieldTextControllerValidator(
      BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Field is required!';
    }

    if (val.length < 8) {
      return 'Password must be at least 8 characters long! ';
    }
    if (val.length > 128) {
      return 'Password length must not exceed 128! ';
    }
    if (!RegExp(
            '^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@\$!%*?&])[A-Za-z\\d@\$!%*?&]{8,}\$')
        .hasMatch(val)) {
      return 'Invalid text';
    }
    return null;
  }

  // State field(s) for ConfirmNewPassword widget.
  FocusNode? confirmNewPasswordFocusNode;
  TextEditingController? confirmNewPasswordTextController;
  late bool confirmNewPasswordVisibility;
  String? Function(BuildContext, String?)?
      confirmNewPasswordTextControllerValidator;

  @override
  void initState(BuildContext context) {
    newPasswordFieldVisibility = false;
    newPasswordFieldTextControllerValidator =
        _newPasswordFieldTextControllerValidator;
    confirmNewPasswordVisibility = false;
  }

  @override
  void dispose() {
    newPasswordFieldFocusNode?.dispose();
    newPasswordFieldTextController?.dispose();

    confirmNewPasswordFocusNode?.dispose();
    confirmNewPasswordTextController?.dispose();
  }
}
