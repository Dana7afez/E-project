import '/flutter_flow/flutter_flow_util.dart';
import 'empty_education_widget.dart' show EmptyEducationWidget;
import 'package:flutter/material.dart';

class EmptyEducationModel extends FlutterFlowModel<EmptyEducationWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
