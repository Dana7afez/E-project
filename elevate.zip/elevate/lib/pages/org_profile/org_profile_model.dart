import '/flutter_flow/flutter_flow_util.dart';
import 'org_profile_widget.dart' show OrgProfileWidget;
import 'package:flutter/material.dart';

class OrgProfileModel extends FlutterFlowModel<OrgProfileWidget> {
  ///  Local state fields for this page.

  List<String> benifits = [];
  void addToBenifits(String item) => benifits.add(item);
  void removeFromBenifits(String item) => benifits.remove(item);
  void removeAtIndexFromBenifits(int index) => benifits.removeAt(index);
  void insertAtIndexInBenifits(int index, String item) =>
      benifits.insert(index, item);
  void updateBenifitsAtIndex(int index, Function(String) updateFn) =>
      benifits[index] = updateFn(benifits[index]);

  ///  State fields for stateful widgets in this page.

  // State field(s) for TabBar widget.
  TabController? tabBarController;
  int get tabBarCurrentIndex =>
      tabBarController != null ? tabBarController!.index : 0;

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for BenifitField widget.
  FocusNode? benifitFieldFocusNode;
  TextEditingController? benifitFieldTextController;
  String? Function(BuildContext, String?)? benifitFieldTextControllerValidator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController3;
  String? Function(BuildContext, String?)? textController3Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode3;
  TextEditingController? textController4;
  String? Function(BuildContext, String?)? textController4Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode4;
  TextEditingController? textController5;
  String? Function(BuildContext, String?)? textController5Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode5;
  TextEditingController? textController6;
  String? Function(BuildContext, String?)? textController6Validator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    tabBarController?.dispose();
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    benifitFieldFocusNode?.dispose();
    benifitFieldTextController?.dispose();

    textFieldFocusNode2?.dispose();
    textController3?.dispose();

    textFieldFocusNode3?.dispose();
    textController4?.dispose();

    textFieldFocusNode4?.dispose();
    textController5?.dispose();

    textFieldFocusNode5?.dispose();
    textController6?.dispose();
  }
}
