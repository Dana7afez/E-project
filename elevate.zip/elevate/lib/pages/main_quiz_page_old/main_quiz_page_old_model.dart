import '/flutter_flow/flutter_flow_util.dart';
import 'main_quiz_page_old_widget.dart' show MainQuizPageOldWidget;
import 'package:flutter/material.dart';

class MainQuizPageOldModel extends FlutterFlowModel<MainQuizPageOldWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
