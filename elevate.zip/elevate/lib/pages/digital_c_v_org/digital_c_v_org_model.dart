import '/flutter_flow/flutter_flow_util.dart';
import 'digital_c_v_org_widget.dart' show DigitalCVOrgWidget;
import 'package:flutter/material.dart';

class DigitalCVOrgModel extends FlutterFlowModel<DigitalCVOrgWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
