import '/flutter_flow/flutter_flow_util.dart';
import 'settings_j_s_widget.dart' show SettingsJSWidget;
import 'package:flutter/material.dart';

class SettingsJSModel extends FlutterFlowModel<SettingsJSWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
