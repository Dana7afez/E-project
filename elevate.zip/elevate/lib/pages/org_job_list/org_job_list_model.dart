import '/flutter_flow/flutter_flow_util.dart';
import '/pages/org_nav_bar/org_nav_bar_widget.dart';
import 'org_job_list_widget.dart' show OrgJobListWidget;
import 'package:flutter/material.dart';

class OrgJobListModel extends FlutterFlowModel<OrgJobListWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for orgNavBar component.
  late OrgNavBarModel orgNavBarModel;

  @override
  void initState(BuildContext context) {
    orgNavBarModel = createModel(context, () => OrgNavBarModel());
  }

  @override
  void dispose() {
    orgNavBarModel.dispose();
  }
}
