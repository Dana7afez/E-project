import '/flutter_flow/flutter_flow_util.dart';
import 'tutorial_org_widget.dart' show TutorialOrgWidget;
import 'package:flutter/material.dart';

class TutorialOrgModel extends FlutterFlowModel<TutorialOrgWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
