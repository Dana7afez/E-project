
abstract class FFAppConstants {
  static const int maxWidthLarge = 1170;
  static const int maxWidthMedium = 830;
}
