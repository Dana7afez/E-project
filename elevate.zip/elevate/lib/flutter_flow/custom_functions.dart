import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

List<bool>? checkEmailExsist(String? email) {
  // Check if the email is null or empty
  if (email == null || email.isEmpty) {
    return [false]; // Return a list with false if the email is invalid
  }

  // Create a placeholder for the result
  List<bool>? result = [false];

  // Call Firestore asynchronously
  FirebaseFirestore.instance
      .collection('users') // Adjust to your actual collection name
      .where('email', isEqualTo: email)
      .get()
      .then((querySnapshot) {
    // Check if any documents were found
    result[0] = querySnapshot.docs.isNotEmpty; // Update the result
  }).catchError((e) {
    print("Error checking email existence: $e");
    result[0] = false; // Return false in case of an error
  });

  return result; // Return the result immediately (may not reflect async changes)
}
