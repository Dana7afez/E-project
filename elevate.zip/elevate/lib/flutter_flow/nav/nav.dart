import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';

import '/auth/base_auth_user_provider.dart';

import '/backend/push_notifications/push_notifications_handler.dart'
    show PushNotificationsHandler;
import '/index.dart';
import '/main.dart';
import '/flutter_flow/flutter_flow_util.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) =>
          appStateNotifier.loggedIn ? const NavBarPage() : const HomepageWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) =>
              appStateNotifier.loggedIn ? const NavBarPage() : const HomepageWidget(),
        ),
        FFRoute(
          name: 'profile_Categories',
          path: '/profileCategories',
          builder: (context, params) => const ProfileCategoriesWidget(),
        ),
        FFRoute(
          name: 'UploadCVpdf',
          path: '/uploadCVpdf',
          builder: (context, params) => const UploadCVpdfWidget(),
        ),
        FFRoute(
          name: 'EditJobSeeker',
          path: '/editJobSeeker',
          builder: (context, params) => EditJobSeekerWidget(
            firstName: params.getParam(
              'firstName',
              ParamType.String,
            ),
            lastName: params.getParam(
              'lastName',
              ParamType.String,
            ),
            title: params.getParam(
              'title',
              ParamType.String,
            ),
            education: params.getParam(
              'education',
              ParamType.String,
            ),
            city: params.getParam(
              'city',
              ParamType.String,
            ),
            phone: params.getParam(
              'phone',
              ParamType.String,
            ),
            photo: params.getParam(
              'photo',
              ParamType.String,
            ),
            uplodimage: params.getParam(
              'uplodimage',
              ParamType.FFUploadedFile,
            ),
          ),
        ),
        FFRoute(
          name: 'jprofile',
          path: '/jprofile',
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'jprofile')
              : JprofileWidget(
                  photo: params.getParam(
                    'photo',
                    ParamType.String,
                  ),
                ),
        ),
        FFRoute(
          name: 'Homepage',
          path: '/homepage',
          builder: (context, params) => const HomepageWidget(),
        ),
        FFRoute(
          name: 'SignInOrg',
          path: '/signInOrg',
          builder: (context, params) => const SignInOrgWidget(),
        ),
        FFRoute(
          name: 'SignUpJobseeker',
          path: '/signUpJobseeker',
          builder: (context, params) => const SignUpJobseekerWidget(),
        ),
        FFRoute(
          name: 'JScompleteSignUp',
          path: '/jScompleteSignUp',
          builder: (context, params) => const JScompleteSignUpWidget(),
        ),
        FFRoute(
          name: 'SignInJS',
          path: '/signInJS',
          builder: (context, params) => const SignInJSWidget(),
        ),
        FFRoute(
          name: 'SignUpOrg',
          path: '/signUpOrg',
          builder: (context, params) => const SignUpOrgWidget(),
        ),
        FFRoute(
          name: 'SignUpOptions',
          path: '/signUpOptions',
          builder: (context, params) => const SignUpOptionsWidget(),
        ),
        FFRoute(
          name: 'DigitalCVJobseeker',
          path: '/digitalCVJobseeker',
          builder: (context, params) => const DigitalCVJobseekerWidget(),
        ),
        FFRoute(
          name: 'settingsJS',
          path: '/settingsJS',
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'settingsJS')
              : const SettingsJSWidget(),
        ),
        FFRoute(
          name: 'settingsOrg',
          path: '/settingsOrg',
          builder: (context, params) => const SettingsOrgWidget(),
        ),
        FFRoute(
          name: 'PerformanceOld',
          path: '/performanceOld',
          builder: (context, params) => const PerformanceOldWidget(),
        ),
        FFRoute(
          name: 'Notifications',
          path: '/notifications',
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'Notifications')
              : NotificationsWidget(
                  userRef: params.getParam(
                    'userRef',
                    ParamType.DocumentReference,
                    isList: false,
                    collectionNamePath: ['users'],
                  ),
                ),
        ),
        FFRoute(
          name: 'jobOpportunities',
          path: '/jobOpportunities',
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'jobOpportunities')
              : const JobOpportunitiesWidget(),
        ),
        FFRoute(
          name: 'AIQuiz',
          path: '/aIQuiz',
          asyncParams: {
            'quizCollection': getDoc(['Quiz'], QuizRecord.fromSnapshot),
          },
          builder: (context, params) => AIQuizWidget(
            skill: params.getParam(
              'skill',
              ParamType.String,
            ),
            question1: params.getParam(
              'question1',
              ParamType.String,
            ),
            quesetion2: params.getParam(
              'quesetion2',
              ParamType.String,
            ),
            question3: params.getParam(
              'question3',
              ParamType.String,
            ),
            question4: params.getParam(
              'question4',
              ParamType.String,
            ),
            question5: params.getParam(
              'question5',
              ParamType.String,
            ),
            question6: params.getParam(
              'question6',
              ParamType.String,
            ),
            question7: params.getParam(
              'question7',
              ParamType.String,
            ),
            question8: params.getParam(
              'question8',
              ParamType.String,
            ),
            question9: params.getParam(
              'question9',
              ParamType.String,
            ),
            question10: params.getParam(
              'question10',
              ParamType.String,
            ),
            allQuestions: params.getParam(
              'allQuestions',
              ParamType.String,
            ),
            quizCollection: params.getParam(
              'quizCollection',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: 'viewJobDetailsOrg',
          path: '/viewJobDetailsOrg',
          builder: (context, params) => ViewJobDetailsOrgWidget(
            selectedJobTitle: params.getParam(
              'selectedJobTitle',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'ForgotPassword',
          path: '/forgotPassword',
          builder: (context, params) => const ForgotPasswordWidget(),
        ),
        FFRoute(
          name: 'CheckEmail',
          path: '/checkEmail',
          builder: (context, params) => CheckEmailWidget(
            emailResetField: params.getParam(
              'emailResetField',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'Education',
          path: '/education',
          builder: (context, params) => const EducationWidget(),
        ),
        FFRoute(
          name: 'Experience',
          path: '/experience',
          builder: (context, params) => const ExperienceWidget(),
        ),
        FFRoute(
          name: 'MainQuizPageOld',
          path: '/mainQuizPageOld',
          builder: (context, params) => const MainQuizPageOldWidget(),
        ),
        FFRoute(
          name: 'StartQuizPage',
          path: '/startQuizPage',
          builder: (context, params) => const StartQuizPageWidget(),
        ),
        FFRoute(
          name: 'OrgProfile',
          path: '/orgProfile',
          builder: (context, params) => const OrgProfileWidget(),
        ),
        FFRoute(
          name: 'JobeekerViewJobDetails',
          path: '/jobeekerViewJobDetails',
          builder: (context, params) => JobeekerViewJobDetailsWidget(
            selectedJobTitle: params.getParam(
              'selectedJobTitle',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'ApplicableJobseeker',
          path: '/applicableJobseeker',
          builder: (context, params) => ApplicableJobseekerWidget(
            selectedJob: params.getParam(
              'selectedJob',
              ParamType.String,
            ),
            skill: params.getParam(
              'skill',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'OrgJobList',
          path: '/orgJobList',
          builder: (context, params) => const OrgJobListWidget(),
        ),
        FFRoute(
          name: 'PostJob',
          path: '/postJob',
          builder: (context, params) => const PostJobWidget(),
        ),
        FFRoute(
          name: 'Performance',
          path: '/performance',
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'Performance')
              : const PerformanceWidget(),
        ),
        FFRoute(
          name: 'MainQuizPage',
          path: '/mainQuizPage',
          builder: (context, params) => const MainQuizPageWidget(),
        ),
        FFRoute(
          name: 'EditOrgProfile',
          path: '/editOrgProfile',
          builder: (context, params) => EditOrgProfileWidget(
            firstName: params.getParam(
              'firstName',
              ParamType.String,
            ),
            lastName: params.getParam(
              'lastName',
              ParamType.String,
            ),
            title: params.getParam(
              'title',
              ParamType.String,
            ),
            education: params.getParam(
              'education',
              ParamType.String,
            ),
            city: params.getParam(
              'city',
              ParamType.String,
            ),
            phone: params.getParam(
              'phone',
              ParamType.String,
            ),
            photo: params.getParam(
              'photo',
              ParamType.String,
            ),
            uplodimage: params.getParam(
              'uplodimage',
              ParamType.FFUploadedFile,
            ),
          ),
        ),
        FFRoute(
          name: 'TutorialJS',
          path: '/tutorialJS',
          builder: (context, params) => const TutorialJSWidget(),
        ),
        FFRoute(
          name: 'TutorialOrg',
          path: '/tutorialOrg',
          builder: (context, params) => const TutorialOrgWidget(),
        ),
        FFRoute(
          name: 'SetNewPassword',
          path: '/setNewPassword',
          builder: (context, params) => const SetNewPasswordWidget(),
        ),
        FFRoute(
          name: 'ApplicableJobseekerCopy',
          path: '/applicableJobseekerCopy',
          builder: (context, params) => ApplicableJobseekerCopyWidget(
            selectedJob: params.getParam(
              'selectedJob',
              ParamType.String,
            ),
            skill: params.getParam(
              'skill',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'DigitalCVOrg',
          path: '/digitalCVOrg',
          builder: (context, params) => DigitalCVOrgWidget(
            jobseekerID: params.getParam(
              'jobseekerID',
              ParamType.String,
            ),
            documentID: params.getParam(
              'documentID',
              ParamType.String,
            ),
            displayName: params.getParam(
              'displayName',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'MainQuizPageCopy2',
          path: '/mainQuizPageCopy2',
          builder: (context, params) => params.isEmpty
              ? const NavBarPage(initialPage: 'MainQuizPageCopy2')
              : const MainQuizPageCopy2Widget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
      observers: [routeObserver],
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/homepage';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Container(
                  color: Colors.transparent,
                  child: Image.asset(
                    'assets/images/dfjsb_6.png',
                    fit: BoxFit.cover,
                  ),
                )
              : PushNotificationsHandler(child: page);

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => const TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
