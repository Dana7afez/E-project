import 'dart:convert';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GetFirstQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the definintion of: {$skill} and make sure the question is only about actual job skill not random words and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetFirstQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetSecondQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the founder of the: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetSecondQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetThirdQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about tools related to the: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetThirdQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetFourthQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the principles of the: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetFourthQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetFifthQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the applications of: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetFifthQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetSixthQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the requirements needed for: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetSixthQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetSeventhQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the date when: {$skill} was first introduced and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetSeventhQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetEighthQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about best practices of: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetEighthQuestion',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetNinthQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about wrong practices in: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetNinthQuestion ',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetTenthQuestionCall {
  static Future<ApiCallResponse> call({
    String? skill = '',
    String? aPISecretkey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Create a multiple-choice question about the benefits of: {$skill} and make sure that the question is not repeated in any previuos response."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetTenthQuestion ',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetSkillRecommendationCall {
  static Future<ApiCallResponse> call({
    String? skillToImprove = '',
    String? aPISecretKey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Generate a profissional Path (Steps) to improve:$skillToImprove "
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetSkillRecommendation',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class GetJobPositionRecommendationCall {
  static Future<ApiCallResponse> call({
    String? jobPosition = '',
    String? aPISecretKey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "Generate a profissional Path (Steps) to become a:$jobPosition "
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'GetJobPositionRecommendation',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CalcQuizScoreCall {
  static Future<ApiCallResponse> call({
    String? quizData =
        '1. What does URL stand for? A. Universal Routing Language B. Uniform Resource Locator\\nC. Unique Resource Link\\nD. United Resource Locator\\n\\n2. Which programming language is commonly used for web development?\\nA. Java\\nB. C++\\nC. Python\\nD. HTML/CSS/JavaScript\\n\\n3. What does CSS stand for in web development?\\nA. Cascading Style Sheets\\nB. Computer Style Sheets\\nC. Creative Style Sheets\\nD. Code Style Sheets\\n\\n4. Which of the following is NOT a web browser?\\nA. Chrome\\nB. Safari\\nC. Java\\nD. Firefox\\n\\n5. What does SEO stand for in the context of websites?\\nA. Search Engine Optimization\\nB. Site Enhancement Optimization\\nC. Social Engagement Outreach\\nD. Search Engine Outreach\\n\\n6. What is the purpose of a web server?\\nA. To store and manage website files\\nB. To design the layout of a website\\nC. To install plugins on a website\\nD. To create content for a website\\n\\n7. Which technology is used for creating responsive web design?\\nA. Flash\\nB. PHP\\nC. Bootstrap\\nD. jQuery\\n\\n8. What is the purpose of a domain name?\\nA. To display ads on a website\\nB. To identify a website on the internet\\nC. To host a website\\nD. To design a website layout\\n\\n9. Which protocol is commonly used for secure web browsing?\\nA. HTTP\\nB. SMTP\\nC. FTP\\nD. HTTPS\\n\\n10. What is the purpose of cookies on a website?\\nA. To track user activity and preferences\\nB. To block access to the website\\nC. To display advertisements\\nD. To design the website layout',
    String? answers = 'A, B, C, D, A, D, C, C, D, A',
    String? aPISecretKey = '',
  }) async {
    final ffApiRequestBody = '''
{
  "model": "gpt-3.5-turbo",
  "messages": [
    {
      "role": "user",
      "content": "calculate Result to this Quiz {${escapeStringForJson(quizData)}} and these are the answers {${escapeStringForJson(answers)}} and Give me the result directly out of 10."
    }
  ],
  "temperature": 0.7
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'CalcQuizScore',
      apiUrl: 'https://api.openai.com/v1/chat/completions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'Authorization':
            'Bearer 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',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
