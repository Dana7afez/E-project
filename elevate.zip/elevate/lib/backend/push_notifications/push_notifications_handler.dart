import 'dart:async';

import 'serialization_util.dart';
import '/backend/backend.dart';
import '../../flutter_flow/flutter_flow_util.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';


final _handledMessageIds = <String?>{};

class PushNotificationsHandler extends StatefulWidget {
  const PushNotificationsHandler({super.key, required this.child});

  final Widget child;

  @override
  _PushNotificationsHandlerState createState() =>
      _PushNotificationsHandlerState();
}

class _PushNotificationsHandlerState extends State<PushNotificationsHandler> {
  bool _loading = false;

  Future handleOpenedPushNotification() async {
    if (isWeb) {
      return;
    }

    final notification = await FirebaseMessaging.instance.getInitialMessage();
    if (notification != null) {
      await _handlePushNotification(notification);
    }
    FirebaseMessaging.onMessageOpenedApp.listen(_handlePushNotification);
  }

  Future _handlePushNotification(RemoteMessage message) async {
    if (_handledMessageIds.contains(message.messageId)) {
      return;
    }
    _handledMessageIds.add(message.messageId);

    safeSetState(() => _loading = true);
    try {
      final initialPageName = message.data['initialPageName'] as String;
      final initialParameterData = getInitialParameterData(message.data);
      final parametersBuilder = parametersBuilderMap[initialPageName];
      if (parametersBuilder != null) {
        final parameterData = await parametersBuilder(initialParameterData);
        context.pushNamed(
          initialPageName,
          pathParameters: parameterData.pathParameters,
          extra: parameterData.extra,
        );
      }
    } catch (e) {
      print('Error: $e');
    } finally {
      safeSetState(() => _loading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    SchedulerBinding.instance.addPostFrameCallback((_) {
      handleOpenedPushNotification();
    });
  }

  @override
  Widget build(BuildContext context) => _loading
      ? Container(
          color: Colors.transparent,
          child: Image.asset(
            'assets/images/dfjsb_6.png',
            fit: BoxFit.cover,
          ),
        )
      : widget.child;
}

class ParameterData {
  const ParameterData(
      {this.requiredParams = const {}, this.allParams = const {}});
  final Map<String, String?> requiredParams;
  final Map<String, dynamic> allParams;

  Map<String, String> get pathParameters => Map.fromEntries(
        requiredParams.entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
  Map<String, dynamic> get extra => Map.fromEntries(
        allParams.entries.where((e) => e.value != null),
      );

  static Future<ParameterData> Function(Map<String, dynamic>) none() =>
      (data) async => const ParameterData();
}

final parametersBuilderMap =
    <String, Future<ParameterData> Function(Map<String, dynamic>)>{
  'profile_Categories': ParameterData.none(),
  'UploadCVpdf': ParameterData.none(),
  'EditJobSeeker': (data) async => ParameterData(
        allParams: {
          'firstName': getParameter<String>(data, 'firstName'),
          'lastName': getParameter<String>(data, 'lastName'),
          'title': getParameter<String>(data, 'title'),
          'education': getParameter<String>(data, 'education'),
          'city': getParameter<String>(data, 'city'),
          'phone': getParameter<String>(data, 'phone'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'jprofile': (data) async => ParameterData(
        allParams: {
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'Homepage': ParameterData.none(),
  'SignInOrg': ParameterData.none(),
  'SignUpJobseeker': ParameterData.none(),
  'JScompleteSignUp': ParameterData.none(),
  'SignInJS': ParameterData.none(),
  'SignUpOrg': ParameterData.none(),
  'SignUpOptions': ParameterData.none(),
  'DigitalCVJobseeker': ParameterData.none(),
  'settingsJS': ParameterData.none(),
  'settingsOrg': ParameterData.none(),
  'PerformanceOld': ParameterData.none(),
  'Notifications': (data) async => ParameterData(
        allParams: {
          'userRef': getParameter<DocumentReference>(data, 'userRef'),
        },
      ),
  'jobOpportunities': ParameterData.none(),
  'AIQuiz': (data) async => ParameterData(
        allParams: {
          'skill': getParameter<String>(data, 'skill'),
          'question1': getParameter<String>(data, 'question1'),
          'quesetion2': getParameter<String>(data, 'quesetion2'),
          'question3': getParameter<String>(data, 'question3'),
          'question4': getParameter<String>(data, 'question4'),
          'question5': getParameter<String>(data, 'question5'),
          'question6': getParameter<String>(data, 'question6'),
          'question7': getParameter<String>(data, 'question7'),
          'question8': getParameter<String>(data, 'question8'),
          'question9': getParameter<String>(data, 'question9'),
          'question10': getParameter<String>(data, 'question10'),
          'allQuestions': getParameter<String>(data, 'allQuestions'),
          'quizCollection': await getDocumentParameter<QuizRecord>(
              data, 'quizCollection', QuizRecord.fromSnapshot),
        },
      ),
  'viewJobDetailsOrg': (data) async => ParameterData(
        allParams: {
          'selectedJobTitle': getParameter<String>(data, 'selectedJobTitle'),
        },
      ),
  'ForgotPassword': ParameterData.none(),
  'CheckEmail': (data) async => ParameterData(
        allParams: {
          'emailResetField': getParameter<String>(data, 'emailResetField'),
        },
      ),
  'Education': ParameterData.none(),
  'Experience': ParameterData.none(),
  'MainQuizPageOld': ParameterData.none(),
  'StartQuizPage': ParameterData.none(),
  'OrgProfile': ParameterData.none(),
  'JobeekerViewJobDetails': (data) async => ParameterData(
        allParams: {
          'selectedJobTitle': getParameter<String>(data, 'selectedJobTitle'),
        },
      ),
  'ApplicableJobseeker': (data) async => ParameterData(
        allParams: {
          'selectedJob': getParameter<String>(data, 'selectedJob'),
          'skill': getParameter<String>(data, 'skill'),
        },
      ),
  'OrgJobList': ParameterData.none(),
  'PostJob': ParameterData.none(),
  'Performance': ParameterData.none(),
  'MainQuizPage': ParameterData.none(),
  'EditOrgProfile': (data) async => ParameterData(
        allParams: {
          'firstName': getParameter<String>(data, 'firstName'),
          'lastName': getParameter<String>(data, 'lastName'),
          'title': getParameter<String>(data, 'title'),
          'education': getParameter<String>(data, 'education'),
          'city': getParameter<String>(data, 'city'),
          'phone': getParameter<String>(data, 'phone'),
          'photo': getParameter<String>(data, 'photo'),
        },
      ),
  'TutorialJS': ParameterData.none(),
  'TutorialOrg': ParameterData.none(),
  'SetNewPassword': ParameterData.none(),
  'ApplicableJobseekerCopy': (data) async => ParameterData(
        allParams: {
          'selectedJob': getParameter<String>(data, 'selectedJob'),
          'skill': getParameter<String>(data, 'skill'),
        },
      ),
  'DigitalCVOrg': (data) async => ParameterData(
        allParams: {
          'jobseekerID': getParameter<String>(data, 'jobseekerID'),
          'documentID': getParameter<String>(data, 'documentID'),
          'displayName': getParameter<String>(data, 'displayName'),
        },
      ),
  'MainQuizPageCopy2': ParameterData.none(),
};

Map<String, dynamic> getInitialParameterData(Map<String, dynamic> data) {
  try {
    final parameterDataStr = data['parameterData'];
    if (parameterDataStr == null ||
        parameterDataStr is! String ||
        parameterDataStr.isEmpty) {
      return {};
    }
    return jsonDecode(parameterDataStr) as Map<String, dynamic>;
  } catch (e) {
    print('Error parsing parameter data: $e');
    return {};
  }
}
