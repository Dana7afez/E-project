import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyCzsMg6wr3OJIqLgq6fY3PzWrCzS9PUhZM",
            authDomain: "calendar-ff298.firebaseapp.com",
            projectId: "calendar-ff298",
            storageBucket: "calendar-ff298.appspot.com",
            messagingSenderId: "39432484711",
            appId: "1:39432484711:web:de040cfde3b2c806bea1c2",
            measurementId: "G-2N3CY33QCS"));
  } else {
    await Firebase.initializeApp();
  }
}
