import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class QuizRecord extends FirestoreRecord {
  QuizRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "Skill" field.
  String? _skill;
  String get skill => _skill ?? '';
  bool hasSkill() => _skill != null;

  // "JobseekerID" field.
  String? _jobseekerID;
  String get jobseekerID => _jobseekerID ?? '';
  bool hasJobseekerID() => _jobseekerID != null;

  // "correctAnswers" field.
  int? _correctAnswers;
  int get correctAnswers => _correctAnswers ?? 0;
  bool hasCorrectAnswers() => _correctAnswers != null;

  // "Q1" field.
  String? _q1;
  String get q1 => _q1 ?? '';
  bool hasQ1() => _q1 != null;

  // "Q2" field.
  String? _q2;
  String get q2 => _q2 ?? '';
  bool hasQ2() => _q2 != null;

  // "Q3" field.
  String? _q3;
  String get q3 => _q3 ?? '';
  bool hasQ3() => _q3 != null;

  // "Q4" field.
  String? _q4;
  String get q4 => _q4 ?? '';
  bool hasQ4() => _q4 != null;

  // "Q5" field.
  String? _q5;
  String get q5 => _q5 ?? '';
  bool hasQ5() => _q5 != null;

  // "Q6" field.
  String? _q6;
  String get q6 => _q6 ?? '';
  bool hasQ6() => _q6 != null;

  // "Q7" field.
  String? _q7;
  String get q7 => _q7 ?? '';
  bool hasQ7() => _q7 != null;

  // "Q8" field.
  String? _q8;
  String get q8 => _q8 ?? '';
  bool hasQ8() => _q8 != null;

  // "Q9" field.
  String? _q9;
  String get q9 => _q9 ?? '';
  bool hasQ9() => _q9 != null;

  // "Q10" field.
  String? _q10;
  String get q10 => _q10 ?? '';
  bool hasQ10() => _q10 != null;

  // "userAnswers" field.
  String? _userAnswers;
  String get userAnswers => _userAnswers ?? '';
  bool hasUserAnswers() => _userAnswers != null;

  // "result" field.
  String? _result;
  String get result => _result ?? '';
  bool hasResult() => _result != null;

  // "JobseekerFirstName" field.
  String? _jobseekerFirstName;
  String get jobseekerFirstName => _jobseekerFirstName ?? '';
  bool hasJobseekerFirstName() => _jobseekerFirstName != null;

  // "JobseekerLastName" field.
  String? _jobseekerLastName;
  String get jobseekerLastName => _jobseekerLastName ?? '';
  bool hasJobseekerLastName() => _jobseekerLastName != null;

  // "JobseekerBio" field.
  String? _jobseekerBio;
  String get jobseekerBio => _jobseekerBio ?? '';
  bool hasJobseekerBio() => _jobseekerBio != null;

  // "JobseekerEmail" field.
  String? _jobseekerEmail;
  String get jobseekerEmail => _jobseekerEmail ?? '';
  bool hasJobseekerEmail() => _jobseekerEmail != null;

  void _initializeFields() {
    _skill = snapshotData['Skill'] as String?;
    _jobseekerID = snapshotData['JobseekerID'] as String?;
    _correctAnswers = castToType<int>(snapshotData['correctAnswers']);
    _q1 = snapshotData['Q1'] as String?;
    _q2 = snapshotData['Q2'] as String?;
    _q3 = snapshotData['Q3'] as String?;
    _q4 = snapshotData['Q4'] as String?;
    _q5 = snapshotData['Q5'] as String?;
    _q6 = snapshotData['Q6'] as String?;
    _q7 = snapshotData['Q7'] as String?;
    _q8 = snapshotData['Q8'] as String?;
    _q9 = snapshotData['Q9'] as String?;
    _q10 = snapshotData['Q10'] as String?;
    _userAnswers = snapshotData['userAnswers'] as String?;
    _result = snapshotData['result'] as String?;
    _jobseekerFirstName = snapshotData['JobseekerFirstName'] as String?;
    _jobseekerLastName = snapshotData['JobseekerLastName'] as String?;
    _jobseekerBio = snapshotData['JobseekerBio'] as String?;
    _jobseekerEmail = snapshotData['JobseekerEmail'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Quiz');

  static Stream<QuizRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => QuizRecord.fromSnapshot(s));

  static Future<QuizRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => QuizRecord.fromSnapshot(s));

  static QuizRecord fromSnapshot(DocumentSnapshot snapshot) => QuizRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static QuizRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      QuizRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'QuizRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is QuizRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createQuizRecordData({
  String? skill,
  String? jobseekerID,
  int? correctAnswers,
  String? q1,
  String? q2,
  String? q3,
  String? q4,
  String? q5,
  String? q6,
  String? q7,
  String? q8,
  String? q9,
  String? q10,
  String? userAnswers,
  String? result,
  String? jobseekerFirstName,
  String? jobseekerLastName,
  String? jobseekerBio,
  String? jobseekerEmail,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Skill': skill,
      'JobseekerID': jobseekerID,
      'correctAnswers': correctAnswers,
      'Q1': q1,
      'Q2': q2,
      'Q3': q3,
      'Q4': q4,
      'Q5': q5,
      'Q6': q6,
      'Q7': q7,
      'Q8': q8,
      'Q9': q9,
      'Q10': q10,
      'userAnswers': userAnswers,
      'result': result,
      'JobseekerFirstName': jobseekerFirstName,
      'JobseekerLastName': jobseekerLastName,
      'JobseekerBio': jobseekerBio,
      'JobseekerEmail': jobseekerEmail,
    }.withoutNulls,
  );

  return firestoreData;
}

class QuizRecordDocumentEquality implements Equality<QuizRecord> {
  const QuizRecordDocumentEquality();

  @override
  bool equals(QuizRecord? e1, QuizRecord? e2) {
    return e1?.skill == e2?.skill &&
        e1?.jobseekerID == e2?.jobseekerID &&
        e1?.correctAnswers == e2?.correctAnswers &&
        e1?.q1 == e2?.q1 &&
        e1?.q2 == e2?.q2 &&
        e1?.q3 == e2?.q3 &&
        e1?.q4 == e2?.q4 &&
        e1?.q5 == e2?.q5 &&
        e1?.q6 == e2?.q6 &&
        e1?.q7 == e2?.q7 &&
        e1?.q8 == e2?.q8 &&
        e1?.q9 == e2?.q9 &&
        e1?.q10 == e2?.q10 &&
        e1?.userAnswers == e2?.userAnswers &&
        e1?.result == e2?.result &&
        e1?.jobseekerFirstName == e2?.jobseekerFirstName &&
        e1?.jobseekerLastName == e2?.jobseekerLastName &&
        e1?.jobseekerBio == e2?.jobseekerBio &&
        e1?.jobseekerEmail == e2?.jobseekerEmail;
  }

  @override
  int hash(QuizRecord? e) => const ListEquality().hash([
        e?.skill,
        e?.jobseekerID,
        e?.correctAnswers,
        e?.q1,
        e?.q2,
        e?.q3,
        e?.q4,
        e?.q5,
        e?.q6,
        e?.q7,
        e?.q8,
        e?.q9,
        e?.q10,
        e?.userAnswers,
        e?.result,
        e?.jobseekerFirstName,
        e?.jobseekerLastName,
        e?.jobseekerBio,
        e?.jobseekerEmail
      ]);

  @override
  bool isValidKey(Object? o) => o is QuizRecord;
}
