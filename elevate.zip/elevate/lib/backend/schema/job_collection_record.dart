import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class JobCollectionRecord extends FirestoreRecord {
  JobCollectionRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "RequiredSkills" field.
  String? _requiredSkills;
  String get requiredSkills => _requiredSkills ?? '';
  bool hasRequiredSkills() => _requiredSkills != null;

  // "Description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "Salary" field.
  String? _salary;
  String get salary => _salary ?? '';
  bool hasSalary() => _salary != null;

  // "JobTitle" field.
  String? _jobTitle;
  String get jobTitle => _jobTitle ?? '';
  bool hasJobTitle() => _jobTitle != null;

  // "KeyReqs" field.
  String? _keyReqs;
  String get keyReqs => _keyReqs ?? '';
  bool hasKeyReqs() => _keyReqs != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "SpecificQuizSkill" field.
  String? _specificQuizSkill;
  String get specificQuizSkill => _specificQuizSkill ?? '';
  bool hasSpecificQuizSkill() => _specificQuizSkill != null;

  // "OrgID" field.
  String? _orgID;
  String get orgID => _orgID ?? '';
  bool hasOrgID() => _orgID != null;

  // "OrgName" field.
  String? _orgName;
  String get orgName => _orgName ?? '';
  bool hasOrgName() => _orgName != null;

  // "Catagory" field.
  String? _catagory;
  String get catagory => _catagory ?? '';
  bool hasCatagory() => _catagory != null;

  // "ReqSkills" field.
  List<String>? _reqSkills;
  List<String> get reqSkills => _reqSkills ?? const [];
  bool hasReqSkills() => _reqSkills != null;

  // "Expyears" field.
  String? _expyears;
  String get expyears => _expyears ?? '';
  bool hasExpyears() => _expyears != null;

  // "Responsibilities" field.
  String? _responsibilities;
  String get responsibilities => _responsibilities ?? '';
  bool hasResponsibilities() => _responsibilities != null;

  // "JobType1" field.
  String? _jobType1;
  String get jobType1 => _jobType1 ?? '';
  bool hasJobType1() => _jobType1 != null;

  // "JobType2" field.
  String? _jobType2;
  String get jobType2 => _jobType2 ?? '';
  bool hasJobType2() => _jobType2 != null;

  // "JobSkill" field.
  String? _jobSkill;
  String get jobSkill => _jobSkill ?? '';
  bool hasJobSkill() => _jobSkill != null;

  void _initializeFields() {
    _requiredSkills = snapshotData['RequiredSkills'] as String?;
    _description = snapshotData['Description'] as String?;
    _location = snapshotData['location'] as String?;
    _salary = snapshotData['Salary'] as String?;
    _jobTitle = snapshotData['JobTitle'] as String?;
    _keyReqs = snapshotData['KeyReqs'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _specificQuizSkill = snapshotData['SpecificQuizSkill'] as String?;
    _orgID = snapshotData['OrgID'] as String?;
    _orgName = snapshotData['OrgName'] as String?;
    _catagory = snapshotData['Catagory'] as String?;
    _reqSkills = getDataList(snapshotData['ReqSkills']);
    _expyears = snapshotData['Expyears'] as String?;
    _responsibilities = snapshotData['Responsibilities'] as String?;
    _jobType1 = snapshotData['JobType1'] as String?;
    _jobType2 = snapshotData['JobType2'] as String?;
    _jobSkill = snapshotData['JobSkill'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('JobCollection');

  static Stream<JobCollectionRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => JobCollectionRecord.fromSnapshot(s));

  static Future<JobCollectionRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => JobCollectionRecord.fromSnapshot(s));

  static JobCollectionRecord fromSnapshot(DocumentSnapshot snapshot) =>
      JobCollectionRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static JobCollectionRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      JobCollectionRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'JobCollectionRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is JobCollectionRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createJobCollectionRecordData({
  String? requiredSkills,
  String? description,
  String? location,
  String? salary,
  String? jobTitle,
  String? keyReqs,
  DateTime? timestamp,
  String? specificQuizSkill,
  String? orgID,
  String? orgName,
  String? catagory,
  String? expyears,
  String? responsibilities,
  String? jobType1,
  String? jobType2,
  String? jobSkill,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'RequiredSkills': requiredSkills,
      'Description': description,
      'location': location,
      'Salary': salary,
      'JobTitle': jobTitle,
      'KeyReqs': keyReqs,
      'timestamp': timestamp,
      'SpecificQuizSkill': specificQuizSkill,
      'OrgID': orgID,
      'OrgName': orgName,
      'Catagory': catagory,
      'Expyears': expyears,
      'Responsibilities': responsibilities,
      'JobType1': jobType1,
      'JobType2': jobType2,
      'JobSkill': jobSkill,
    }.withoutNulls,
  );

  return firestoreData;
}

class JobCollectionRecordDocumentEquality
    implements Equality<JobCollectionRecord> {
  const JobCollectionRecordDocumentEquality();

  @override
  bool equals(JobCollectionRecord? e1, JobCollectionRecord? e2) {
    const listEquality = ListEquality();
    return e1?.requiredSkills == e2?.requiredSkills &&
        e1?.description == e2?.description &&
        e1?.location == e2?.location &&
        e1?.salary == e2?.salary &&
        e1?.jobTitle == e2?.jobTitle &&
        e1?.keyReqs == e2?.keyReqs &&
        e1?.timestamp == e2?.timestamp &&
        e1?.specificQuizSkill == e2?.specificQuizSkill &&
        e1?.orgID == e2?.orgID &&
        e1?.orgName == e2?.orgName &&
        e1?.catagory == e2?.catagory &&
        listEquality.equals(e1?.reqSkills, e2?.reqSkills) &&
        e1?.expyears == e2?.expyears &&
        e1?.responsibilities == e2?.responsibilities &&
        e1?.jobType1 == e2?.jobType1 &&
        e1?.jobType2 == e2?.jobType2 &&
        e1?.jobSkill == e2?.jobSkill;
  }

  @override
  int hash(JobCollectionRecord? e) => const ListEquality().hash([
        e?.requiredSkills,
        e?.description,
        e?.location,
        e?.salary,
        e?.jobTitle,
        e?.keyReqs,
        e?.timestamp,
        e?.specificQuizSkill,
        e?.orgID,
        e?.orgName,
        e?.catagory,
        e?.reqSkills,
        e?.expyears,
        e?.responsibilities,
        e?.jobType1,
        e?.jobType2,
        e?.jobSkill
      ]);

  @override
  bool isValidKey(Object? o) => o is JobCollectionRecord;
}
