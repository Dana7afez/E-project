import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "shortDescription" field.
  String? _shortDescription;
  String get shortDescription => _shortDescription ?? '';
  bool hasShortDescription() => _shortDescription != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "tags" field.
  List<CategoriesStruct>? _tags;
  List<CategoriesStruct> get tags => _tags ?? const [];
  bool hasTags() => _tags != null;

  // "FirstNameJ" field.
  String? _firstNameJ;
  String get firstNameJ => _firstNameJ ?? '';
  bool hasFirstNameJ() => _firstNameJ != null;

  // "LastnameJ" field.
  String? _lastnameJ;
  String get lastnameJ => _lastnameJ ?? '';
  bool hasLastnameJ() => _lastnameJ != null;

  // "City" field.
  String? _city;
  String get city => _city ?? '';
  bool hasCity() => _city != null;

  // "Gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "DateOfBirth" field.
  DateTime? _dateOfBirth;
  DateTime? get dateOfBirth => _dateOfBirth;
  bool hasDateOfBirth() => _dateOfBirth != null;

  // "skills" field.
  String? _skills;
  String get skills => _skills ?? '';
  bool hasSkills() => _skills != null;

  // "Bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "backgroundPic" field.
  String? _backgroundPic;
  String get backgroundPic => _backgroundPic ?? '';
  bool hasBackgroundPic() => _backgroundPic != null;

  // "experience" field.
  String? _experience;
  String get experience => _experience ?? '';
  bool hasExperience() => _experience != null;

  // "Position" field.
  String? _position;
  String get position => _position ?? '';
  bool hasPosition() => _position != null;

  // "isOrg" field.
  bool? _isOrg;
  bool get isOrg => _isOrg ?? false;
  bool hasIsOrg() => _isOrg != null;

  // "Token" field.
  String? _token;
  String get token => _token ?? '';
  bool hasToken() => _token != null;

  // "OrgAddress" field.
  String? _orgAddress;
  String get orgAddress => _orgAddress ?? '';
  bool hasOrgAddress() => _orgAddress != null;

  // "education" field.
  String? _education;
  String get education => _education ?? '';
  bool hasEducation() => _education != null;

  // "UsersRef" field.
  DocumentReference? _usersRef;
  DocumentReference? get usersRef => _usersRef;
  bool hasUsersRef() => _usersRef != null;

  // "UserRefList" field.
  List<DocumentReference>? _userRefList;
  List<DocumentReference> get userRefList => _userRefList ?? const [];
  bool hasUserRefList() => _userRefList != null;

  // "pdfCV" field.
  String? _pdfCV;
  String get pdfCV => _pdfCV ?? '';
  bool hasPdfCV() => _pdfCV != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _shortDescription = snapshotData['shortDescription'] as String?;
    _title = snapshotData['title'] as String?;
    _tags = getStructList(
      snapshotData['tags'],
      CategoriesStruct.fromMap,
    );
    _firstNameJ = snapshotData['FirstNameJ'] as String?;
    _lastnameJ = snapshotData['LastnameJ'] as String?;
    _city = snapshotData['City'] as String?;
    _gender = snapshotData['Gender'] as String?;
    _dateOfBirth = snapshotData['DateOfBirth'] as DateTime?;
    _skills = snapshotData['skills'] as String?;
    _bio = snapshotData['Bio'] as String?;
    _backgroundPic = snapshotData['backgroundPic'] as String?;
    _experience = snapshotData['experience'] as String?;
    _position = snapshotData['Position'] as String?;
    _isOrg = snapshotData['isOrg'] as bool?;
    _token = snapshotData['Token'] as String?;
    _orgAddress = snapshotData['OrgAddress'] as String?;
    _education = snapshotData['education'] as String?;
    _usersRef = snapshotData['UsersRef'] as DocumentReference?;
    _userRefList = getDataList(snapshotData['UserRefList']);
    _pdfCV = snapshotData['pdfCV'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? shortDescription,
  String? title,
  String? firstNameJ,
  String? lastnameJ,
  String? city,
  String? gender,
  DateTime? dateOfBirth,
  String? skills,
  String? bio,
  String? backgroundPic,
  String? experience,
  String? position,
  bool? isOrg,
  String? token,
  String? orgAddress,
  String? education,
  DocumentReference? usersRef,
  String? pdfCV,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'shortDescription': shortDescription,
      'title': title,
      'FirstNameJ': firstNameJ,
      'LastnameJ': lastnameJ,
      'City': city,
      'Gender': gender,
      'DateOfBirth': dateOfBirth,
      'skills': skills,
      'Bio': bio,
      'backgroundPic': backgroundPic,
      'experience': experience,
      'Position': position,
      'isOrg': isOrg,
      'Token': token,
      'OrgAddress': orgAddress,
      'education': education,
      'UsersRef': usersRef,
      'pdfCV': pdfCV,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.shortDescription == e2?.shortDescription &&
        e1?.title == e2?.title &&
        listEquality.equals(e1?.tags, e2?.tags) &&
        e1?.firstNameJ == e2?.firstNameJ &&
        e1?.lastnameJ == e2?.lastnameJ &&
        e1?.city == e2?.city &&
        e1?.gender == e2?.gender &&
        e1?.dateOfBirth == e2?.dateOfBirth &&
        e1?.skills == e2?.skills &&
        e1?.bio == e2?.bio &&
        e1?.backgroundPic == e2?.backgroundPic &&
        e1?.experience == e2?.experience &&
        e1?.position == e2?.position &&
        e1?.isOrg == e2?.isOrg &&
        e1?.token == e2?.token &&
        e1?.orgAddress == e2?.orgAddress &&
        e1?.education == e2?.education &&
        e1?.usersRef == e2?.usersRef &&
        listEquality.equals(e1?.userRefList, e2?.userRefList) &&
        e1?.pdfCV == e2?.pdfCV;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.shortDescription,
        e?.title,
        e?.tags,
        e?.firstNameJ,
        e?.lastnameJ,
        e?.city,
        e?.gender,
        e?.dateOfBirth,
        e?.skills,
        e?.bio,
        e?.backgroundPic,
        e?.experience,
        e?.position,
        e?.isOrg,
        e?.token,
        e?.orgAddress,
        e?.education,
        e?.usersRef,
        e?.userRefList,
        e?.pdfCV
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
