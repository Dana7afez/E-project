import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SkillRecommendationRecord extends FirestoreRecord {
  SkillRecommendationRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "SkillToImprove" field.
  String? _skillToImprove;
  String get skillToImprove => _skillToImprove ?? '';
  bool hasSkillToImprove() => _skillToImprove != null;

  // "JobseekerID" field.
  String? _jobseekerID;
  String get jobseekerID => _jobseekerID ?? '';
  bool hasJobseekerID() => _jobseekerID != null;

  // "Recommendation" field.
  String? _recommendation;
  String get recommendation => _recommendation ?? '';
  bool hasRecommendation() => _recommendation != null;

  // "Timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  void _initializeFields() {
    _skillToImprove = snapshotData['SkillToImprove'] as String?;
    _jobseekerID = snapshotData['JobseekerID'] as String?;
    _recommendation = snapshotData['Recommendation'] as String?;
    _timestamp = snapshotData['Timestamp'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('SkillRecommendation');

  static Stream<SkillRecommendationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SkillRecommendationRecord.fromSnapshot(s));

  static Future<SkillRecommendationRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => SkillRecommendationRecord.fromSnapshot(s));

  static SkillRecommendationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SkillRecommendationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SkillRecommendationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SkillRecommendationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SkillRecommendationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SkillRecommendationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSkillRecommendationRecordData({
  String? skillToImprove,
  String? jobseekerID,
  String? recommendation,
  DateTime? timestamp,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'SkillToImprove': skillToImprove,
      'JobseekerID': jobseekerID,
      'Recommendation': recommendation,
      'Timestamp': timestamp,
    }.withoutNulls,
  );

  return firestoreData;
}

class SkillRecommendationRecordDocumentEquality
    implements Equality<SkillRecommendationRecord> {
  const SkillRecommendationRecordDocumentEquality();

  @override
  bool equals(SkillRecommendationRecord? e1, SkillRecommendationRecord? e2) {
    return e1?.skillToImprove == e2?.skillToImprove &&
        e1?.jobseekerID == e2?.jobseekerID &&
        e1?.recommendation == e2?.recommendation &&
        e1?.timestamp == e2?.timestamp;
  }

  @override
  int hash(SkillRecommendationRecord? e) => const ListEquality().hash(
      [e?.skillToImprove, e?.jobseekerID, e?.recommendation, e?.timestamp]);

  @override
  bool isValidKey(Object? o) => o is SkillRecommendationRecord;
}
